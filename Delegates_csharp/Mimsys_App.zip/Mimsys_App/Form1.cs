﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mimsys_App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        // event handler method.
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Welcome to Mimsys Technologies!";
            textBox1.BackColor = Color.Yellow;
        }

        private void textBox1_MouseHover(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.Green;
        }

        private void textBox1_MouseLeave()
        {
            textBox1.BackColor = Color.Yellow;
        }



    }
}
